$(document).ready(function() {
  $('p')
    .hide()
    .highlightOnce({duration: 2000})
    .slideDown();
});
