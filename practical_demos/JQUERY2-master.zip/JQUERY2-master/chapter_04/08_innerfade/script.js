$(document).ready(function() {
  $('#news ul').innerfade({
    animationtype: 'slide',
    speed: 750,
    timeout: 3000,
    type: 'random'
  });
});