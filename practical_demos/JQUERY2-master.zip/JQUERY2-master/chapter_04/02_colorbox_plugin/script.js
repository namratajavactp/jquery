$(document).ready(function(){
  $('a[rel=celeb]').colorbox({
    transition: 'fade',
    speed: 500,
    current: "{current} of {total} celebrity photos"
  });

});

