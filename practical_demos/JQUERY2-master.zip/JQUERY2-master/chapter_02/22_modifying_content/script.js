$(document).ready(function(){
  $('p').html('good bye, cruel paragraphs!');
  $('h2').text('All your titles are belong to us');
});