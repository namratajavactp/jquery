$(document).ready(function(){
  alert($('#celebs tr').length + ' elements!');
});