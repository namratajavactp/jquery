$(document).ready(function(){
  $('#celebs tbody tr:even').addClass('zebra');
});