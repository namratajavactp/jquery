$(document).ready(function(){
  $('#hideButton').click(function(){
    $('#disclaimer').hide();
  });
  $('#showButton').click(function(){
    $('#disclaimer').show();
  });
});