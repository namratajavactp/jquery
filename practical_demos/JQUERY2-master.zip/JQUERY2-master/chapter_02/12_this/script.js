$(document).ready(function() {
  $('#hideButton').click(function(){
    $(this).hide();
  });
});