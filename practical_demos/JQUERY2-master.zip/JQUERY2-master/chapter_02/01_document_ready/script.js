$(document).ready(function(){
  alert('Welcome to StarTrackr! Now no longer under police investigation!');
});