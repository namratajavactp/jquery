$(document).ready(function(){
  alert($('#celebs tbody tr:even').length + ' elements!');
});