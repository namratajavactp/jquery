$(document).ready(function(){
  $('p').animate({ 
    padding: '20px',
    fontSize: '30px'
  }, 2000);
});