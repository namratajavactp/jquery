$(document).ready(function() {
  $(window).resize(function() {
    alert("You resized the window!");
  });
});
