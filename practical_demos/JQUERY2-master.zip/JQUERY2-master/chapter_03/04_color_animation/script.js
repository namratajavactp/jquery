$(document).ready(function(){
  $('#disclaimer').animate({'backgroundColor':'#ff9f5f'}, 2000);
});
