$(document).ready(function () {
  $(window).scroll(function () {
    $('#navigation').css('top', $(document).scrollTop()); 
  });
});
