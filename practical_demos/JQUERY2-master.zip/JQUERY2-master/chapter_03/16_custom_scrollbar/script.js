$(document).ready(function() {
    $('#fine_print').jScrollPane({
        verticalGutter: 20
    });
});