$(document).ready(function(){
  $('#accordion').accordion({header: 'h3'});
  $('#accordion').accordion('activate', 2);
});
